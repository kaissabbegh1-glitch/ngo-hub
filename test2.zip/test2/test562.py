import streamlit_authenticator as stauth

passwords = ["funfun123", "blacknigga123"]
hasher = stauth.Hasher(passwords)
hashed = hasher.generate()

print("Hash pour funfun123  :", hashed[0])
print("Hash pour blacknigga123:", hashed[1])
exit()