import streamlit as st
import yaml
from yaml.loader import SafeLoader
import streamlit_authenticator as stauth

with open('config.yaml', encoding='utf-8') as f:
    config = yaml.load(f, Loader=SafeLoader)

auth = stauth.Authenticate(
    config['credentials'],
    config['cookie']['name'],
    config['cookie']['key'],
    config['cookie']['expiry_days']
)

result = auth.login(location='main')

if result is None:
    st.error("authenticate.login() returned None → config.yaml invalide ou passwords non hashés")
    st.stop()

name, auth_status, user = result

if auth_status:
    st.success(f"Connecté : {name}")
    auth.logout('Déconnexion', 'sidebar')
elif auth_status is False:
    st.error("Identifiants incorrects")
else:
    st.info("Connectez-vous")