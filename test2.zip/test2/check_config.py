import yaml
from yaml.loader import SafeLoader

try:
    with open('config.yaml', encoding='utf-8') as f:
        cfg = yaml.load(f, Loader=SafeLoader)
    print("Config loaded OK")
    print("Users:", list(cfg['credentials']['usernames'].keys()))
    print("Cookie name:", cfg['cookie']['name'])
    print("Has preauthorized?", 'preauthorized' in cfg)
except Exception as e:
    print("ERROR:", e)