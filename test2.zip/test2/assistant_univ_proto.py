import os
import streamlit as st
import yaml
from yaml.loader import SafeLoader
import streamlit_authenticator as stauth

from langchain_community.document_loaders import PyPDFDirectoryLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

# ─── CONFIG ────────────────────────────────────────────────────────────────
DOCS_FOLDER     = "./docs"
CHROMA_PATH     = "./chroma_db_univ"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
LLM_MODEL       = "llama3.1:8b"
CHUNK_SIZE      = 900
CHUNK_OVERLAP   = 180

# ─── LOAD CONFIG ───────────────────────────────────────────────────────────
try:
    with open("config.yaml", encoding="utf-8") as f:
        config = yaml.load(f, Loader=SafeLoader)
except Exception as e:
    st.error(f"Erreur config.yaml : {e}")
    st.stop()

authenticator = stauth.Authenticate(
    config["credentials"],
    config["cookie"]["name"],
    config["cookie"]["key"],
    config["cookie"]["expiry_days"],
)

# ─── RAG PIPELINE ──────────────────────────────────────────────────────────
@st.cache_resource(show_spinner="Chargement/indexation documents...")
def get_vectorstore():
    if not os.path.exists(DOCS_FOLDER) or not os.listdir(DOCS_FOLDER):
        st.error(f"Dossier {DOCS_FOLDER} vide ou inexistant.")
        st.stop()

    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)

    if os.path.exists(CHROMA_PATH):
        return Chroma(persist_directory=CHROMA_PATH, embedding_function=embeddings)

    loader = PyPDFDirectoryLoader(DOCS_FOLDER)
    docs = loader.load()

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        add_start_index=True
    )
    chunks = splitter.split_documents(docs)

    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=CHROMA_PATH
    )
    return vectorstore


def build_rag_chain(vectorstore):
    llm = ChatOllama(
        model=LLM_MODEL,
        temperature=0.1,
        num_ctx=8192,
        timeout=180
    )

    retriever = vectorstore.as_retriever(search_kwargs={"k": 5})

    prompt = ChatPromptTemplate.from_template("""\
Tu es un assistant administratif fiable de l'université.
Réponds UNIQUEMENT avec les informations présentes dans les documents officiels.
Sois précis, poli, structuré.
Si l'information n'est PAS dans les documents fournis, réponds exactement :
« Cette information n'est pas disponible dans les documents officiels actuels. Veuillez contacter le secrétariat. »

Contexte :
{context}

Question :
{question}

Réponse :
""")

    chain = (
        {
            "context": retriever | (lambda docs: "\n\n".join(
                f"[p. {d.metadata.get('page', '?')}] {d.page_content.strip()}"
                for d in docs
            )),
            "question": RunnablePassthrough()
        }
        | prompt
        | llm
        | StrOutputParser()
    )

    return chain


# ─── EMAIL TEMPLATE ────────────────────────────────────────────────────────
def get_email_template(question: str):
    q = question.lower()
    if any(kw in q for kw in ["attestation", "certificat", "scolarité", "relevé", "note"]):
        name = st.session_state.get("name", "[Votre nom]")
        return f"""Objet : Demande de certificat / attestation

Madame, Monsieur,

Je soussigné(e) {name},
étudiant(e) inscrit(e) dans votre établissement,

Vous prie de bien vouloir me délivrer un certificat / attestation.

Cordialement,
{name}
"""
    return None


# ─── MAIN ──────────────────────────────────────────────────────────────────
def main():
    st.set_page_config(page_title="Assistant Université", layout="wide")

    # ✅ FIXED LOGIN CALL
    name, auth_status, username = authenticator.login(
        location="main"
    )

    if auth_status:
        st.title("🧑‍🎓 Assistant IA – Administration Universitaire")
        st.caption(f"Bienvenue {name}")

        with st.sidebar:
            st.header(f"Connecté : {name}")
            authenticator.logout("Déconnexion", "sidebar")
            st.session_state["name"] = name

        vectorstore = get_vectorstore()
        chain = build_rag_chain(vectorstore)

        if "messages" not in st.session_state:
            st.session_state.messages = []

        for msg in st.session_state.messages:
            with st.chat_message(msg["role"]):
                st.markdown(msg["content"])

        if prompt := st.chat_input("Posez votre question administrative…"):
            st.session_state.messages.append({"role": "user", "content": prompt})

            with st.chat_message("assistant"):
                with st.spinner("Recherche..."):
                    try:
                        answer = chain.invoke(prompt)
                        st.markdown(answer)

                        email_tpl = get_email_template(prompt)
                        if email_tpl:
                            st.info("Modèle d'email suggéré :")
                            st.code(email_tpl)

                        st.session_state.messages.append(
                            {"role": "assistant", "content": answer}
                        )

                    except Exception as e:
                        st.error(f"Erreur : {e}")

    elif auth_status is False:
        st.error("Identifiant ou mot de passe incorrect")

    else:
        st.warning("Veuillez vous connecter")

    # ✅ FIXED REGISTER CALL
    if st.button("S'inscrire (nouvel étudiant)"):
        try:
            email, username, name = authenticator.register_user(
                location="main"
            )
            if email:
                st.success("Compte créé avec succès !")
                st.rerun()
        except Exception as e:
            st.error(f"Erreur inscription : {e}")


if __name__ == "__main__":
    main()