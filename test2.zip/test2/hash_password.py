# hash_password.py
import bcrypt
import getpass

def hash_password():
    password = getpass.getpass("Entrez le mot de passe à hasher : ").strip()
    if not password:
        print("Mot de passe vide – abandon.")
        return
    
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    print("\nHash généré (copiez-le tel quel) :")
    print(hashed.decode('utf-8'))
    print("\nCollez-le dans config.yaml sous password: (sans guillemets)")

if __name__ == "__main__":
    hash_password()